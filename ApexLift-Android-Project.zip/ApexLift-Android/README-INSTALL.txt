APEXLIFT ANDROID PROJECT
=======================

This is an Android Studio project for a native Android WebView app wrapper.
The workout interface and tracking logic run locally inside the app.

BUILD THE APK (requires a Windows, macOS, or Linux computer)
1. Install Android Studio (current stable version).
2. Open Android Studio -> Open.
3. Select the extracted "ApexLift-Android" folder (the folder containing settings.gradle).
4. Allow Gradle sync and install Android SDK Platform 35 if prompted.
5. Select Build -> Build Bundle(s) / APK(s) -> Build APK(s).
6. When complete, choose "locate" in the notification. The APK is normally:
   app/build/outputs/apk/debug/app-debug.apk
7. Transfer app-debug.apk to your Android tablet.
8. Open the APK on the tablet and allow installation from that source if Android asks.

NOTES
- This source package is NOT itself an APK. It must be compiled with Android Studio.
- This environment did not have the Android SDK or Gradle installed, so an APK could not be compiled or verified here.
- Exercise video buttons open YouTube search results; internet is needed for those.
- Workout logs and progress are stored locally in the app's WebView storage. Export your progress from the app regularly.
- For release distribution, create a signed APK from Android Studio's Build -> Generate Signed Bundle / APK menu.
